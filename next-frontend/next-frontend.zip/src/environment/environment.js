const environment = {
  apiUrl: "http://localhost/Nextjs%20Projects/next-project-idb/server/api/",
  imageUrl: "http://localhost/Nextjs%20Projects/next-project-idb/server/img/",
};

export default environment;
