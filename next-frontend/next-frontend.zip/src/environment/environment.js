// const environment = {
//   apiUrl: "http://localhost/Nextjs%20Projects/next-project-idb/server/api/",
//   imageUrl: "http://localhost/Nextjs%20Projects/next-project-idb/server/img/",
// };
const environment = {
  apiUrl: "http://server.skmiraj.online/nextsuperhostelidb/api/",
  imageUrl: "http://server.skmiraj.online/nextsuperhostelidb/img/",
};

export default environment;
