
const logOut = ()=>{
    localStorage.removeItem('token');
}

export default logOut;